import {
  PlannedPitStop,
  PlannedStopHudStatus,
  PreRacePitStrategy,
  TyreCompound,
  WeatherMode,
} from '../types/racing';

export interface GForceVector {
  gLat: number; // Positive = turn left / force right, Negative = turn right / force left
  gLong: number; // Positive = acceleration, Negative = braking deceleration
  gTotal: number;
}

export interface CockpitCameraOffsets {
  pitch: number; // Radians to tilt camera down/up
  roll: number; // Radians to tilt camera sideways
  yaw: number; // Radians to pan camera (look to apex)
  offsetFwd: number; // Meters displacement along forward axis (head moving fwd under braking)
  offsetRight: number; // Meters displacement along right axis (head swaying in corner)
  offsetY: number; // Meters vertical displacement (chassis compression / buffeting)
  buffetShake: number; // High-speed aerodynamic turbulence intensity
}

export interface StrategyCalculationResult {
  pitWindowStartLap: number;
  pitWindowEndLap: number;
  isWindowOpen: boolean;
  recommendedCompound: TyreCompound;
  estimatedPitLossSec: number;
  undercutViable: boolean;
  undercutDeltaSec: number | null;
  predictedExitPosition: number;
  tyreDegradationStage: 'fresh' | 'optimal' | 'degrading' | 'cliff';
  tacticalRadioCall: string | null;
  startingCompound?: TyreCompound;
  startingFuelPct?: number;
  plannedStops?: PlannedStopHudStatus[];
  nextPlannedStop?: PlannedPitStop | null;
  estimatedFuelLapsRemaining?: number;
}

export interface StintLapPoint {
  lap: number;
  compound: TyreCompound;
  tyreWearStartPct: number;
  tyreWearEndPct: number;
  fuelStartPct: number;
  fuelEndPct: number;
  isPitLap: boolean;
  pitToCompound?: TyreCompound;
  refuelTargetPct?: number;
}

export interface StrategyProjection {
  lapPoints: StintLapPoint[];
  fuelBurnPerLapPct: number;
  fuelMarginLaps: number;
  runsOutOfFuelLap: number | null;
  minTyreWearPct: number;
  fuelWeightDeltaSecPerLap: number;
  estimatedPitTimeTotalSec: number;
  stints: Array<{
    stintNumber: number;
    startLap: number;
    endLap: number;
    compound: TyreCompound;
    laps: number;
  }>;
}

const GRAVITY = 9.80665;
const PIT_STOP_TRANSIT_LOSS = 20.5; // Average F1 pit lane delta in seconds
export const BASE_FUEL_BURN_PER_LAP_PCT = 14.5; // ~14.5% per race lap (so >6 laps requires fuel planning or 1-stop refuel)

export function getCompoundWearPerLap(compound: TyreCompound, weather: WeatherMode | 'wet' = 'day'): number {
  const isWetWeather = weather === 'rain' || weather === 'heavy_rain' || weather === 'wet';
  if (compound === 'soft') return isWetWeather ? 26 : 18.5;
  if (compound === 'medium') return isWetWeather ? 23 : 12.2;
  if (compound === 'hard') return isWetWeather ? 20 : 8.1;
  return isWetWeather ? 11.5 : 22.0; // wet tyre wears fast on dry track
}

export function buildDefaultPitStrategy(
  totalLaps: number,
  weather: WeatherMode,
  preferredStartingCompound?: TyreCompound
): PreRacePitStrategy {
  const laps = Math.max(1, Math.round(totalLaps));
  const isWet = weather === 'rain' || weather === 'heavy_rain';
  const startCmp: TyreCompound = isWet
    ? 'wet'
    : preferredStartingCompound && preferredStartingCompound !== 'wet'
      ? preferredStartingCompound
      : laps <= 4
        ? 'soft'
        : 'medium';

  if (laps <= 3) {
    return {
      totalLaps: laps,
      startingCompound: startCmp,
      startingFuelPct: Math.min(100, Math.max(55, Math.round(laps * BASE_FUEL_BURN_PER_LAP_PCT + 14))),
      stops: [],
    };
  }

  if (laps <= 8) {
    const pitLap = Math.max(1, Math.min(laps - 1, Math.round(laps * 0.45)));
    const nextCmp: TyreCompound = isWet ? 'wet' : startCmp === 'soft' ? 'medium' : 'hard';
    const secondStintLaps = laps - pitLap;
    return {
      totalLaps: laps,
      startingCompound: startCmp,
      startingFuelPct: Math.min(100, Math.max(50, Math.round(pitLap * BASE_FUEL_BURN_PER_LAP_PCT + 15))),
      stops: [
        {
          id: 'stop_1',
          stopNumber: 1,
          pitLap,
          compound: nextCmp,
          fuelLoadPct: Math.min(100, Math.max(45, Math.round(secondStintLaps * BASE_FUEL_BURN_PER_LAP_PCT + 16))),
        },
      ],
    };
  }

  // 9+ lap races default to balanced 2-stop or 1-stop long strategy
  const stop1Lap = Math.max(1, Math.min(laps - 2, Math.round(laps * 0.34)));
  const stop2Lap = Math.max(stop1Lap + 1, Math.min(laps - 1, Math.round(laps * 0.68)));
  return {
    totalLaps: laps,
    startingCompound: startCmp,
    startingFuelPct: Math.min(100, Math.max(55, Math.round(stop1Lap * BASE_FUEL_BURN_PER_LAP_PCT + 15))),
    stops: [
      {
        id: 'stop_1',
        stopNumber: 1,
        pitLap: stop1Lap,
        compound: isWet ? 'wet' : 'hard',
        fuelLoadPct: Math.min(100, Math.max(50, Math.round((stop2Lap - stop1Lap) * BASE_FUEL_BURN_PER_LAP_PCT + 16))),
      },
      {
        id: 'stop_2',
        stopNumber: 2,
        pitLap: stop2Lap,
        compound: isWet ? 'wet' : 'soft',
        fuelLoadPct: Math.min(100, Math.max(45, Math.round((laps - stop2Lap) * BASE_FUEL_BURN_PER_LAP_PCT + 16))),
      },
    ],
  };
}

export function normalizePitStrategyPlan(plan: PreRacePitStrategy): PreRacePitStrategy {
  const totalLaps = Math.max(1, Math.min(30, Math.round(plan.totalLaps)));
  const sortedStops = [...plan.stops]
    .filter((s) => totalLaps >= 2)
    .map((s) => ({
      ...s,
      pitLap: Math.max(1, Math.min(totalLaps - 1, Math.round(s.pitLap))),
      fuelLoadPct: Math.max(30, Math.min(100, Math.round(s.fuelLoadPct))),
    }))
    .sort((a, b) => a.pitLap - b.pitLap);

  // Deduplicate same-lap stops by nudging subsequent stops forward when possible
  const deduped: PlannedPitStop[] = [];
  for (const s of sortedStops) {
    let lap = s.pitLap;
    while (deduped.some((d) => d.pitLap === lap) && lap < totalLaps - 1) {
      lap++;
    }
    if (!deduped.some((d) => d.pitLap === lap)) {
      deduped.push({
        ...s,
        stopNumber: deduped.length + 1,
        pitLap: lap,
      });
    }
  }

  return {
    totalLaps,
    startingCompound: plan.startingCompound,
    startingFuelPct: Math.max(35, Math.min(100, Math.round(plan.startingFuelPct))),
    stops: deduped.slice(0, 3),
  };
}

export function simulateStrategyProjection(
  rawPlan: PreRacePitStrategy,
  weather: WeatherMode = 'day'
): StrategyProjection {
  const plan = normalizePitStrategyPlan(rawPlan);
  const fuelBurnPerLapPct = Number(
    Math.min(26, Math.max(8, (100 / Math.max(5.5, plan.totalLaps * 0.72)))).toFixed(1)
  );
  // Real-race alignment: shorter races still burn realistic noticeable % per lap
  const effectiveBurn = Math.max(7.5, Math.min(24, plan.totalLaps <= 5 ? 16 : fuelBurnPerLapPct));

  const lapPoints: StintLapPoint[] = [];
  const stints: StrategyProjection['stints'] = [];

  let curCompound: TyreCompound = plan.startingCompound;
  let curWear = 100;
  let curFuel = plan.startingFuelPct;
  let minWear = 100;
  let runsOutOfFuelLap: number | null = null;
  let stintStartLap = 1;
  let stintCount = 1;
  let pitTimeTotal = 0;

  for (let lap = 1; lap <= plan.totalLaps; lap++) {
    const startWear = curWear;
    const startFuel = curFuel;
    const wearLoss = getCompoundWearPerLap(curCompound, weather);
    curWear = Math.max(0, Number((curWear - wearLoss).toFixed(1)));
    curFuel = Math.max(0, Number((curFuel - effectiveBurn).toFixed(1)));
    if (curWear < minWear) minWear = curWear;
    if (curFuel <= 0.1 && runsOutOfFuelLap === null) {
      runsOutOfFuelLap = lap;
    }

    const stopOnLap = plan.stops.find((s) => s.pitLap === lap);
    lapPoints.push({
      lap,
      compound: curCompound,
      tyreWearStartPct: startWear,
      tyreWearEndPct: curWear,
      fuelStartPct: startFuel,
      fuelEndPct: curFuel,
      isPitLap: Boolean(stopOnLap),
      pitToCompound: stopOnLap?.compound,
      refuelTargetPct: stopOnLap?.fuelLoadPct,
    });

    if (stopOnLap) {
      stints.push({
        stintNumber: stintCount++,
        startLap: stintStartLap,
        endLap: lap,
        compound: curCompound,
        laps: lap - stintStartLap + 1,
      });
      const fuelAdded = Math.max(0, stopOnLap.fuelLoadPct - curFuel);
      pitTimeTotal += PIT_STOP_TRANSIT_LOSS + fuelAdded * 0.035;
      curCompound = stopOnLap.compound;
      curWear = 100;
      curFuel = Math.max(curFuel, stopOnLap.fuelLoadPct);
      stintStartLap = lap + 1;
    }
  }

  stints.push({
    stintNumber: stintCount,
    startLap: stintStartLap,
    endLap: plan.totalLaps,
    compound: curCompound,
    laps: Math.max(1, plan.totalLaps - stintStartLap + 1),
  });

  const endFuel = lapPoints[lapPoints.length - 1]?.fuelEndPct ?? 0;
  const fuelMarginLaps = Number((endFuel / effectiveBurn).toFixed(1));
  const fuelWeightDeltaSecPerLap = Number((((plan.startingFuelPct - 50) / 50) * 0.24).toFixed(2));

  return {
    lapPoints,
    fuelBurnPerLapPct: effectiveBurn,
    fuelMarginLaps,
    runsOutOfFuelLap,
    minTyreWearPct: Math.round(minWear),
    fuelWeightDeltaSecPerLap,
    estimatedPitTimeTotalSec: Number(pitTimeTotal.toFixed(1)),
    stints,
  };
}

/**
 * Calculates authentic instantaneous G-forces acting on car and driver.
 */
export function calculateGForces(
  currentSpeedMs: number,
  prevSpeedMs: number,
  turnRateRadPerSec: number,
  dt: number
): GForceVector {
  const safeDt = Math.max(0.001, dt);
  const accelMs2 = (currentSpeedMs - prevSpeedMs) / safeDt;
  const gLongRaw = accelMs2 / GRAVITY;
  // F1 longitudinal Gs: Braking can reach ~ -5.5G, Acceleration ~ +2.0G
  const gLong = Math.max(-5.5, Math.min(2.2, gLongRaw));

  // Centripetal acceleration: a = v * w
  const centripetalMs2 = currentSpeedMs * turnRateRadPerSec;
  const gLatRaw = centripetalMs2 / GRAVITY;
  // F1 lateral Gs: Up to ~ 5.2G in high speed sweepers
  const gLat = Math.max(-5.2, Math.min(5.2, gLatRaw));

  const gTotal = Math.sqrt(gLong * gLong + gLat * gLat);

  return {
    gLat: Number(gLat.toFixed(2)),
    gLong: Number(gLong.toFixed(2)),
    gTotal: Number(gTotal.toFixed(2)),
  };
}

/**
 * Calculates viscoelastic driver head movement and cockpit camera response.
 */
export function calculateCockpitGOffset(
  gLong: number,
  gLat: number,
  speedKmh: number,
  onKerb: boolean,
  _timeSec: number
): CockpitCameraOffsets {
  const pitch = -gLong * 0.022;
  const offsetFwd = -gLong * 0.045;
  const offsetY = -Math.abs(gLong) * 0.018;

  const roll = -gLat * 0.024;
  const offsetRight = -gLat * 0.035;
  const yaw = -gLat * 0.018;

  let buffetShake = 0;
  if (speedKmh > 230) {
    const speedFactor = Math.min(1.0, (speedKmh - 230) / 100);
    buffetShake = speedFactor * 0.038;
  }

  if (onKerb) {
    buffetShake += 0.045;
  }

  return {
    pitch,
    roll,
    yaw,
    offsetFwd,
    offsetRight,
    offsetY,
    buffetShake,
  };
}

/**
 * Calculates hardcore race strategy, optimal pit window, tyre degradation, undercut potential,
 * and evaluates live progress against the pre-planned race pit strategy.
 */
export function calculatePitStrategy(
  currentLap: number,
  totalLaps: number,
  tyreCompound: TyreCompound,
  tyreWearPct: number,
  trackWetnessPct: number,
  gapAheadSeconds: number | null,
  playerPosition: number,
  totalRacers: number,
  fuelPct = 100,
  strategyPlan?: PreRacePitStrategy,
  completedStopIds?: ReadonlySet<string>
): StrategyCalculationResult {
  const windowStart = Math.max(1, Math.floor(totalLaps * 0.35));
  const windowEnd = Math.max(windowStart, Math.min(totalLaps - 1, Math.ceil(totalLaps * 0.65)));
  const isWindowOpen = currentLap >= windowStart && currentLap <= windowEnd;

  let tyreDegradationStage: 'fresh' | 'optimal' | 'degrading' | 'cliff';
  if (tyreWearPct > 80) {
    tyreDegradationStage = 'fresh';
  } else if (tyreWearPct > 55) {
    tyreDegradationStage = 'optimal';
  } else if (tyreWearPct > 28) {
    tyreDegradationStage = 'degrading';
  } else {
    tyreDegradationStage = 'cliff';
  }

  let recommendedCompound: TyreCompound;
  const remainingLaps = Math.max(1, totalLaps - currentLap);

  if (trackWetnessPct > 45) {
    recommendedCompound = 'wet';
  } else if (remainingLaps <= 2) {
    recommendedCompound = 'soft';
  } else if (remainingLaps <= 5) {
    recommendedCompound = tyreCompound === 'medium' ? 'soft' : 'medium';
  } else {
    recommendedCompound = 'hard';
  }

  const undercutViable =
    isWindowOpen &&
    gapAheadSeconds !== null &&
    gapAheadSeconds > 0 &&
    gapAheadSeconds <= 2.8 &&
    playerPosition > 1;

  const undercutDeltaSec = undercutViable ? Number((1.4 + Math.random() * 0.6).toFixed(1)) : null;

  const estimatedPlacesLost = Math.round(PIT_STOP_TRANSIT_LOSS / 2.8);
  const predictedExitPosition = Math.min(totalRacers, playerPosition + estimatedPlacesLost);

  const plannedStops: PlannedStopHudStatus[] = (strategyPlan?.stops ?? []).map((stop) => ({
    ...stop,
    completed: Boolean(completedStopIds?.has(stop.id)),
  }));
  const nextPlannedStop = plannedStops.find((s) => !s.completed) ?? null;

  const burnPerLap = Math.max(7.5, Math.min(24, totalLaps <= 5 ? 16 : 100 / Math.max(5.5, totalLaps * 0.72)));
  const estimatedFuelLapsRemaining = Number((fuelPct / burnPerLap).toFixed(1));

  let tacticalRadioCall: string | null = null;
  if (trackWetnessPct > 50 && tyreCompound !== 'wet') {
    tacticalRadioCall = 'BOX BOX: Track wetness critical. Inters/Wets standing by!';
  } else if (tyreDegradationStage === 'cliff') {
    tacticalRadioCall = 'BOX THIS LAP: Tyres at critical cliff. Box now for fresh compound!';
  } else if (nextPlannedStop && currentLap === nextPlannedStop.pitLap) {
    tacticalRadioCall = `SCHEDULED STOP L${nextPlannedStop.pitLap}: Box this lap for ${nextPlannedStop.compound.toUpperCase()} + ${nextPlannedStop.fuelLoadPct}% fuel.`;
  } else if (undercutViable) {
    tacticalRadioCall = `UNDERCUT WINDOW OPEN: Gap ahead ${gapAheadSeconds?.toFixed(1)}s. Box this lap to jump them!`;
  } else if (isWindowOpen && currentLap === windowStart) {
    tacticalRadioCall = `PIT WINDOW OPEN: Optimal pit window active (Laps ${windowStart}-${windowEnd}).`;
  }

  return {
    pitWindowStartLap: windowStart,
    pitWindowEndLap: windowEnd,
    isWindowOpen,
    recommendedCompound: nextPlannedStop?.compound ?? recommendedCompound,
    estimatedPitLossSec: PIT_STOP_TRANSIT_LOSS,
    undercutViable,
    undercutDeltaSec,
    predictedExitPosition,
    tyreDegradationStage,
    tacticalRadioCall,
    startingCompound: strategyPlan?.startingCompound ?? tyreCompound,
    startingFuelPct: strategyPlan?.startingFuelPct ?? 100,
    plannedStops,
    nextPlannedStop,
    estimatedFuelLapsRemaining,
  };
}
