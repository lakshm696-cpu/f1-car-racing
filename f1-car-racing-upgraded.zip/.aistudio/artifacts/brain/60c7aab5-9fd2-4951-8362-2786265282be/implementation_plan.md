# F1 2026 Hardcore Pro Simulation & Realism Upgrade

## User Review & Critical Decisions

> [!IMPORTANT]
> Based on your preferences, we are upgrading the experience to a **Hardcore Pro Simulation** featuring immersive V6 turbo-hybrid acoustic staging, dynamic G-force camera physics, and intelligent pit window race strategy calculus.

- **Confirmed Pillar**: Immersive V6 turbo-hybrid sound staging & realistic G-force cockpit physics
- **Confirmed Challenge**: Hardcore Pro Simulation with realistic race strategy & pit window calculus

---

## 1. Overview & Core Experience

- **What It Delivers**: 
  1. **Advanced V6 Turbo-Hybrid & HRTF 3D Sound Staging**: High-fidelity combustion harmonics, MGU-K energy harvesting whines, turbocharger spool transients, aerodynamic pass-by whooshes, and dynamic pit radio chatter.
  2. **G-Force Cockpit Physics & Camera Dynamics**: Realistic head-bobbing, centrifugal lateral g-force camera tilt, braking pitch compression, and cockpit vibration.
  3. **Hardcore Race Strategy & Pit Window Calculus**: Real-time tyre degradation, fuel load calculation, undercut/overcut telemetry, and engineer tactical recommendations.

---

## 2. User Experience & Visual Design

- **Aesthetic Direction**: Authentic FIA F1 2026 Broadcast & Telemetry OSD styling.
- **Color Palette & Typography**: Deep carbon obsidian (`#090B0F`), racing accents (`#EF4444`, `#F59E0B`, `#38BDF8`), styled with `Chakra Petch` and `JetBrains Mono`.
- **Interactive Enhancements**: Strategy pit stop calculator overlay, live delta timeline, and enhanced G-force indicator HUD.

---

## 3. Key Technical Architecture & Changes

- **Audio Enhancements in `RacingAudio.ts`**:
  - Fine-tune V6 harmonic frequencies and turbocharger resonance.
  - Enhance HRTF spatial positioning and Doppler frequency shift for AI cars.
- **Physics & Camera Enhancements in `RacingEngine.ts`**:
  - Implement G-force acceleration/braking pitch and lateral cornering roll interpolation.
  - Add tyre wear coefficient and pit window strategy triggers.
- **HUD & Strategy Enhancements in `RacingHUD.tsx`**:
  - Add real-time strategy recommendation cards (Undercut/Overcut window).
  - Add G-force accelerometer visualizer in telemetry.

---

## 4. Verification Plan

- **Compilation**: Run `compile_applet` and `lint_applet` to ensure zero type errors.
- **Functional Checks**: Verify V6 audio unlocks correctly and G-force camera movement responds to high-speed cornering and braking.
